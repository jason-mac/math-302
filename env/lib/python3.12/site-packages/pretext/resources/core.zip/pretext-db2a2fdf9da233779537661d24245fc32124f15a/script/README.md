PreTeXt Script Directory
========================

`mbx`
-----

A stub replacing an obsolete script, which simply tries to
execute the `pretext/pretext` script.  DO NOT USE.

`braille`
----------

Files for converting PreTeXt to Braille, see README there.


